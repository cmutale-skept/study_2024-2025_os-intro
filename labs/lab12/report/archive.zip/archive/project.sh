tar -cvf ~/backup/project.tar project.sh
